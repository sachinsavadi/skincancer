import streamlit as st
import numpy as np
import matplotlib.pyplot as plt

# Define a function to generate random data for metrics
def generate_random_metrics():
    epochs = np.arange(1, 11)
    accuracy = np.random.rand(10)
    val_accuracy = np.random.rand(10)
    loss = np.random.rand(10)
    val_loss = np.random.rand(10)
    precision = np.random.rand(10)
    recall = np.random.rand(10)
    f1_score = np.random.rand(10)
    return epochs, accuracy, val_accuracy, loss, val_loss, precision, recall, f1_score

# Define the Streamlit app
def app():
    st.set_page_config(
        page_title="Metrics Visualization App",
        layout="wide"
    )

    st.title("Metrics Visualization App")

    # Generate random metrics data
    epochs, accuracy, val_accuracy, loss, val_loss, precision, recall, f1_score = generate_random_metrics()

    # Plot accuracy and validation accuracy
    st.subheader("Accuracy and Validation Accuracy")
    fig, ax = plt.subplots()
    ax.plot(epochs, accuracy, label='Accuracy')
    ax.plot(epochs, val_accuracy, label='Validation Accuracy')
    ax.set_xlabel('Epochs')
    ax.set_ylabel('Value')
    ax.legend()
    st.pyplot(fig)

    # Plot loss and validation loss
    st.subheader("Loss and Validation Loss")
    fig, ax = plt.subplots()
    ax.plot(epochs, loss, label='Loss')
    ax.plot(epochs, val_loss, label='Validation Loss')
    ax.set_xlabel('Epochs')
    ax.set_ylabel('Value')
    ax.legend()
    st.pyplot(fig)

    # Plot precision and recall
    st.subheader("Precision and Recall")
    fig, ax = plt.subplots()
    ax.plot(epochs, precision, label='Precision')
    ax.plot(epochs, recall, label='Recall')
    ax.set_xlabel('Epochs')
    ax.set_ylabel('Value')
    ax.legend()
    st.pyplot(fig)

    # Plot F1 score
    st.subheader("F1 Score")
    fig, ax = plt.subplots()
    ax.plot(epochs, f1_score, label='F1 Score')
    ax.set_xlabel('Epochs')
    ax.set_ylabel('Value')
    ax.legend()
    st.pyplot(fig)

# Run the app
if __name__ == '__main__':
    app()
