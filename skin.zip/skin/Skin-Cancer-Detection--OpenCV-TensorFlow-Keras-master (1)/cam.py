import tkinter as tk
from tkinter import filedialog
import cv2
from PIL import Image, ImageTk

def capture_and_save():
    # Capture frame from camera
    ret, frame = cap.read()

    # Display the captured frame using PIL
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(img)
    img = ImageTk.PhotoImage(image=img)

    # Create a tkinter window for displaying the image
    display_window = tk.Toplevel()
    display_window.title("Captured Photo")
    display_label = tk.Label(display_window, image=img)
    display_label.pack()

    # Ask user to select the location to save the image
    save_path = filedialog.asksaveasfilename(defaultextension=".jpg", filetypes=[("JPEG files", "*.jpg")])

    # Save the captured photo
    if save_path:
        cv2.imwrite(save_path, frame)
        print("Image saved successfully at:", save_path)
    else:
        print("No location selected. Image not saved.")

    # Destroy the display window after saving the image
    display_window.destroy()

# Initialize the camera
cap = cv2.VideoCapture(0)

# Create a tkinter window
root = tk.Tk()
root.withdraw()  # Hide the tkinter window

# Call the function to capture and save the image
capture_and_save()

# Release the camera
cap.release()
