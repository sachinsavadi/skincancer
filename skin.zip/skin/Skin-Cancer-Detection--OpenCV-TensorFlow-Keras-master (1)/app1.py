import streamlit as st
import cv2
import numpy as np
from keras.models import load_model
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns

# Load the trained model
model_path = 'skin_cancer_detection_model.h5'
model = load_model(model_path)

# Define the size of the input images
img_size = (224, 224)

# Define a function to preprocess the input image
def preprocess_image(img):
    img = cv2.resize(img, img_size)
    img = np.expand_dims(img, axis=0)
    img = img / 255.0
    return img

# Define a function to categorize the prediction
def categorize_prediction(prob):
    if prob <= 5:
        return "Not Cancer"
    elif 5 < prob <= 6:
        return "Cancer"
    else:
        return "Danger - Please contact a hospital"

# Define the Streamlit app
def app():
    st.set_page_config(
        page_title="Skin Cancer Detection App",
        page_icon="🩺",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    st.title('🩺 Skin Cancer Detection App')
    
    st.markdown(
        """
        <style>
        .reportview-container {
            background: #f0f2f6;
        }
        .sidebar .sidebar-content {
            background: #f0f2f6;
        }
        .stButton button {
            background-color: #4CAF50;
            color: white;
        }
        .stProgress > div > div > div > div {
            background-color: #4CAF50;
        }
        .prediction {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .danger {
            color: red;
        }
        .cancer {
            color: orange;
        }
        .not-cancer {
            color: green;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Display model information
    st.sidebar.title('🔍 Model Information')
    st.sidebar.write(f'**Model Path:** {model_path}')
    st.sidebar.write('**Input Image Size:** 224x224')
    st.sidebar.write('**Model Output:** Probability of Skin Cancer (0-1)')
    
    # Display information about preprocessing
    st.sidebar.title('🖼️ Image Preprocessing')
    st.sidebar.write('1. Resize image to 224x224 pixels.')
    st.sidebar.write('2. Normalize pixel values to range 0-1.')

    # About section
    st.sidebar.title('ℹ️ About')
    st.sidebar.write(
        """
        This application uses a deep learning model to predict the probability of skin cancer from uploaded images. 
        Upload a clear image of the skin lesion for analysis.
        """
    )

    # Explanation of categories
    st.sidebar.title('📊 Prediction Categories')
    st.sidebar.write('**Not Cancer (1-5):** Low probability of skin cancer.')
    st.sidebar.write('**Cancer (6):** Moderate probability of skin cancer.')
    st.sidebar.write('**Danger (>6):** High probability of skin cancer, immediate medical consultation recommended.')

    # Instructions for file upload
    st.markdown("## Instructions")
    st.markdown(
        """
        1. Click on the "Browse files" button below.
        2. Select one or more images of skin lesions.
        3. Wait for the app to process and display the results.
        """
    )

    # Prediction history
    if 'pred_history' not in st.session_state:
        st.session_state.pred_history = []

    # Allow the user to upload images
    uploaded_files = st.file_uploader('Choose images', type=['jpg', 'jpeg', 'png'], accept_multiple_files=True)
    
    if uploaded_files:
        for uploaded_file in uploaded_files:
            try:
                # Read the image
                img = cv2.imdecode(np.frombuffer(uploaded_file.read(), np.uint8), 1)
                # Display the image
                st.image(img, caption=f'Uploaded Image: {uploaded_file.name}', use_column_width=True)

                # Preprocess the image
                st.markdown("### Processing Image")
                with st.spinner('Processing image...'):
                    img = preprocess_image(img)

                # Make a prediction
                st.markdown("### Making Prediction")
                with st.spinner('Making prediction...'):
                    pred = model.predict(img)
                    st.progress(100)
                    pred_prob = pred[0][0] * 9 + 1  # Scale from 0-1 to 1-10
                    pred_label = categorize_prediction(pred_prob)

                    # Add to prediction history
                    st.session_state.pred_history.append({
                        'Image': uploaded_file.name,
                        'Prediction': pred_label,
                        'Probability': pred_prob
                    })

                    # Show the prediction result
                    prediction_class = "danger" if pred_label == "Danger - Please contact a hospital" else "cancer" if pred_label == "Cancer" else "not-cancer"
                    st.markdown(f'<div class="prediction {prediction_class}">Prediction: {pred_label}</div>', unsafe_allow_html=True)
                    st.markdown(f'Probability Of Skin Cancer: **{pred_prob:.1f} / 10**')

                    # Plot the prediction probability
                    fig, ax = plt.subplots()
                    sns.barplot(x=['Probability'], y=[pred_prob], palette=['#4CAF50' if pred_label == "Not Cancer" else '#FFA500' if pred_label == "Cancer" else '#FF0000'])
                    ax.set_ylim(0, 10)
                    ax.set_ylabel('Scale (1-10)')
                    st.pyplot(fig)
                
            except Exception as e:
                st.error(f"Error processing the image: {e}")

    # Display prediction history
    if st.session_state.pred_history:
        st.markdown("## Prediction History")
        pred_df = pd.DataFrame(st.session_state.pred_history)
        st.dataframe(pred_df)

        # Download option for prediction history
        csv = pred_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download Prediction History",
            data=csv,
            file_name='prediction_history.csv',
            mime='text/csv',
        )

# Run the app
if __name__ == '__main__':
    app()
